<?php
declare(strict_types=1);

return array (
  'db' => 
  array (
    'driver' => 'sqlite',
    'host' => '127.0.0.1',
    'port' => 3306,
    'database' => __DIR__ . '/../../database/omnipos.sqlite',
    'username' => '',
    'password' => '',
    'charset' => 'utf8mb4',
  ),
  'security_salt' => 'a5ab3f40149cd648e65caeb3087448c6f932cf2ed7523f47cb3789004c134de8',
  'jwt_secret' => 'e12aa424347b2714277381d2044306c34840085d1e4d944c3c1ddb15ed3b7053',
  'vendor_public_key_hex' => '7cba51469668791a660ee64c5815922b0349dc4e74ae39e2cc9c5d232dacbcf4',
  'installed_at' => 1792904789,
  'online_db' => 
  array (
    'enabled' => false,
    'driver' => 'mysql',
    'host' => 'vendra.charafeddine.xyz',
    'port' => 3306,
    'database' => '',
    'username' => '',
    'password' => '',
    'charset' => 'utf8mb4',
  ),
);
